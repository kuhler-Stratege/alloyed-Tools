package net.modding.blocks.eisenlegierung;

import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;

public class BlockChrom_Ore extends BasicBlockEisen {

	public BlockChrom_Ore() {
		super("chrom_ore", Material.ROCK, 2, 5.5F, SoundType.STONE);
	}
	

}

		
		


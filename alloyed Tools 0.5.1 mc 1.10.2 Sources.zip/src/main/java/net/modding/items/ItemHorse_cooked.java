package net.modding.items;

import java.util.Random;

import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.world.World;

public class ItemHorse_cooked extends BasicFood{

	public ItemHorse_cooked(String name, int amount, boolean isWolfFood) {
		super("horse_cooked", 5, false);
		
	}
	
	@Override
	protected void onFoodEaten(ItemStack stack, World worldIn, EntityPlayer player) {
		setPotionEffect(new PotionEffect(Potion.getPotionById(1), 80, 1), (float) 0.4);
		//Eine Sekunde=20 Ticks
	}
	
}
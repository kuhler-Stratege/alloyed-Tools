package net.modding.items.eisenlegierung.tools;

import net.modding.items.basictools.BasicItemAxe;

public class ItemFerro_axe extends BasicItemAxe{
	
	public ItemFerro_axe() {
		super(registry.ferroMaterial, "ferro", registry.chromTab, 0.6F);
	}	
}
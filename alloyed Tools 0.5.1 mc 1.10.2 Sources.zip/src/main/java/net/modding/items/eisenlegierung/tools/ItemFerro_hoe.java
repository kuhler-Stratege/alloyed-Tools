package net.modding.items.eisenlegierung.tools;


import net.modding.items.basictools.BasicItemHoe;


public class ItemFerro_hoe extends BasicItemHoe{
	
	public ItemFerro_hoe() {
		super(registry.ferroMaterial, "ferro", registry.chromTab);
	}	
}
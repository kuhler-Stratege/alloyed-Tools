package net.modding.items.eisenlegierung.tools;


import net.modding.items.basictools.BasicItemPickaxe;


public class ItemFerro_pickaxe extends BasicItemPickaxe{
	
	public ItemFerro_pickaxe() {
		super(registry.ferroMaterial, "ferro", registry.chromTab);
	}	
}
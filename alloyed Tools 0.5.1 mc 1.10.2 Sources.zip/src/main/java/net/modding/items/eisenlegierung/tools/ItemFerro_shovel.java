package net.modding.items.eisenlegierung.tools;

import net.modding.items.basictools.BasicItemShovel;

public class ItemFerro_shovel extends BasicItemShovel{
	
	public ItemFerro_shovel() {
		super(registry.ferroMaterial, "ferro", registry.chromTab);
	}	
}
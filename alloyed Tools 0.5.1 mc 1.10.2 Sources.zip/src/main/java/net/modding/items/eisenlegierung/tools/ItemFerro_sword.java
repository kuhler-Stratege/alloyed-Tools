package net.modding.items.eisenlegierung.tools;

import net.modding.items.basictools.BasicItemSword;

public class ItemFerro_sword extends BasicItemSword{
	
	public ItemFerro_sword() {
		super(registry.ferroMaterial, "ferro", registry.chromTab, 0.15F);
	}	
}
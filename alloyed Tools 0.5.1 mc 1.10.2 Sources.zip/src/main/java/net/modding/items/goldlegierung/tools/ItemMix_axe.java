package net.modding.items.goldlegierung.tools;

import net.modding.items.basictools.BasicItemAxe;

public class ItemMix_axe extends BasicItemAxe{

	public ItemMix_axe() {
		super(registry.mixMaterial, "mix", registry.platinTab, 0.8F);

	}	
}
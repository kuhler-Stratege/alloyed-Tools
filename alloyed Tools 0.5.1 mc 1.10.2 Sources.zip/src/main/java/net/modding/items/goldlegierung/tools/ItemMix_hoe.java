package net.modding.items.goldlegierung.tools;

import net.modding.items.basictools.BasicItemHoe;

public class ItemMix_hoe extends BasicItemHoe{

	public ItemMix_hoe() {
		super(registry.mixMaterial, "mix", registry.platinTab);

	}	
}
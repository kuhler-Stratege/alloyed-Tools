package net.modding.items.goldlegierung.tools;

import net.modding.items.basictools.BasicItemPickaxe;

public class ItemMix_pickaxe extends BasicItemPickaxe{

	public ItemMix_pickaxe() {
		super(registry.mixMaterial, "mix", registry.platinTab);

	}	
}
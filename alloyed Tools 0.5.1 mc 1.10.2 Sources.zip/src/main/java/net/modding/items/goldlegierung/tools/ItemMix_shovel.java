package net.modding.items.goldlegierung.tools;

import net.modding.items.basictools.BasicItemShovel;

public class ItemMix_shovel extends BasicItemShovel{

	public ItemMix_shovel() {
		super(registry.mixMaterial, "mix", registry.platinTab);

	}	
}
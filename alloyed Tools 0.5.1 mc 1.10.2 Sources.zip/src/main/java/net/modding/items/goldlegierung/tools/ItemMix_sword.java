package net.modding.items.goldlegierung.tools;

import net.modding.items.basictools.BasicItemSword;

public class ItemMix_sword extends BasicItemSword{

	public ItemMix_sword() {
		super(registry.mixMaterial, "mix", registry.platinTab, 0.1F);

	}	
}
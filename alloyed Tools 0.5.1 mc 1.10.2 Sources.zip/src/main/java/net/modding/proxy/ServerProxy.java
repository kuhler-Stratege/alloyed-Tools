package net.modding.proxy;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
public class ServerProxy {
	public void RegisterClientStuff() {
	}
	public void registerEimer() {
	}
	public void registerTeer(FMLInitializationEvent a) {
	}
}	